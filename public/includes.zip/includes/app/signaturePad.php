<script>
$('#signature-pad').signature(); 
</script>
<div id="signature-pad">
</div>
