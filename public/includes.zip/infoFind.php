<?php
require_once("../resources/pdoConnect.php");

?>
<?php include(TEMPLATE_BACK . DS . "appHeader.php") ?>



<?php include(TEMPLATE_BACK . DS . "infoFind.php") ?>