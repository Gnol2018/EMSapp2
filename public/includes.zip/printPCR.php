<?php 
require_once("../resources/pdoConnect.php");
?>
<?php include(TEMPLATE_BACK . DS . "PCRapp/PCRdompdf.php");
?>